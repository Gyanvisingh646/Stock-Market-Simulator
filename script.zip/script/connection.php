<?php
	$servername = "localhost";
	$username = "root";
	$password = "";
	$database = "StockMarketSimulator";

	$conn = mysqli_connect($servername, $username, $password, $database);
	/*if($conn) {
		echo "Connection Succesfull<br>";
	}else {
		echo "Error in Connection<br>";
	}*/	
?>